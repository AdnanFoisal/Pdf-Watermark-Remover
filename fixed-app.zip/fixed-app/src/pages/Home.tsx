import { useState, useRef, useCallback } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { FileUp, Download, X, FileText, Loader2, Droplets, Shield, Zap } from "lucide-react";

export default function Home() {
  const [file, setFile] = useState<File | null>(null);
  const [isDragging, setIsDragging] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [progress, setProgress] = useState(0);
  const [downloadUrl, setDownloadUrl] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  }, []);

  const handleDragLeave = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
  }, []);

  const MAX_FILE_SIZE = 500 * 1024 * 1024; // 500 MB

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    const droppedFile = e.dataTransfer.files[0];
    if (!droppedFile) return;
    if (droppedFile.type !== "application/pdf") {
      setError("Please drop a PDF file");
      return;
    }
    if (droppedFile.size > MAX_FILE_SIZE) {
      setError("File exceeds the 500 MB limit. Please choose a smaller PDF.");
      return;
    }
    setFile(droppedFile);
    setError(null);
    setDownloadUrl(null);
    setProgress(0);
  }, []);

  const handleFileSelect = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = e.target.files?.[0];
    if (!selectedFile) return;
    if (selectedFile.type !== "application/pdf") {
      setError("Please select a PDF file");
      return;
    }
    if (selectedFile.size > MAX_FILE_SIZE) {
      setError("File exceeds the 500 MB limit. Please choose a smaller PDF.");
      return;
    }
    setFile(selectedFile);
    setError(null);
    setDownloadUrl(null);
    setProgress(0);
  }, []);

  const handleRemoveFile = useCallback(() => {
    setFile(null);
    setDownloadUrl(null);
    setError(null);
    setProgress(0);
    if (fileInputRef.current) {
      fileInputRef.current.value = "";
    }
  }, []);

  const handleUpload = async () => {
    if (!file) return;

    setIsProcessing(true);
    setProgress(10);
    setError(null);

    try {
      const formData = new FormData();
      formData.append("pdf", file);

      setProgress(30);

      const response = await fetch("/api/pdf/remove-watermark", {
        method: "POST",
        body: formData,
      });

      setProgress(80);

      if (!response.ok) {
        const data = await response.json().catch(() => ({}));
        throw new Error(data.error || "Failed to process PDF");
      }

      const blob = await response.blob();
      const url = URL.createObjectURL(blob);
      setDownloadUrl(url);
      setProgress(100);
    } catch (err) {
      const message = err instanceof Error ? err.message : "An error occurred";
      setError(message);
    } finally {
      setIsProcessing(false);
    }
  };

  const handleDownload = () => {
    if (!downloadUrl || !file) return;
    const a = document.createElement("a");
    a.href = downloadUrl;
    a.download = file.name.replace(".pdf", "") + "_cleaned.pdf";
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  };

  const formatFileSize = (bytes: number) => {
    if (bytes === 0) return "0 Bytes";
    const k = 1024;
    const sizes = ["Bytes", "KB", "MB", "GB"];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + " " + sizes[i];
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-50 to-white dark:from-slate-950 dark:to-slate-900">
      {/* Header */}
      <header className="border-b bg-white/80 dark:bg-slate-950/80 backdrop-blur-sm sticky top-0 z-50">
        <div className="max-w-5xl mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Droplets className="h-6 w-6 text-blue-600" />
            <h1 className="text-xl font-bold bg-gradient-to-r from-blue-600 to-indigo-600 bg-clip-text text-transparent">
              PDF Watermark Remover
            </h1>
          </div>
        </div>
      </header>

      <main className="max-w-5xl mx-auto px-4 py-12">
        {/* Hero Section */}
        <div className="text-center mb-12">
          <h2 className="text-4xl font-extrabold tracking-tight text-slate-900 dark:text-white mb-4">
            Remove Watermarks from Any PDF
          </h2>
          <p className="text-lg text-slate-600 dark:text-slate-400 max-w-2xl mx-auto">
            Clean your NotebookLLM slides and any other PDFs. Upload your file, 
            we detect and remove watermarks automatically using AI-powered image processing.
          </p>
        </div>

        {/* Features */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
          <Card className="border-0 shadow-md bg-white/60 dark:bg-slate-900/60 backdrop-blur">
            <CardContent className="pt-6 text-center">
              <Zap className="h-8 w-8 text-amber-500 mx-auto mb-3" />
              <h3 className="font-semibold text-slate-900 dark:text-white mb-1">Lightning Fast</h3>
              <p className="text-sm text-slate-600 dark:text-slate-400">
                Process entire presentations in seconds. No queues, no waiting.
              </p>
            </CardContent>
          </Card>
          <Card className="border-0 shadow-md bg-white/60 dark:bg-slate-900/60 backdrop-blur">
            <CardContent className="pt-6 text-center">
              <Shield className="h-8 w-8 text-emerald-500 mx-auto mb-3" />
              <h3 className="font-semibold text-slate-900 dark:text-white mb-1">Private & Secure</h3>
              <p className="text-sm text-slate-600 dark:text-slate-400">
                Files are processed securely and deleted immediately after. Your data never persists.
              </p>
            </CardContent>
          </Card>
          <Card className="border-0 shadow-md bg-white/60 dark:bg-slate-900/60 backdrop-blur">
            <CardContent className="pt-6 text-center">
              <FileText className="h-8 w-8 text-blue-500 mx-auto mb-3" />
              <h3 className="font-semibold text-slate-900 dark:text-white mb-1">Any Size PDF</h3>
              <p className="text-sm text-slate-600 dark:text-slate-400">
                Supports large slide decks and documents. Up to 500MB per file.
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Upload Area */}
        <Card className="border-2 border-dashed shadow-lg">
          <CardContent className="p-8">
            {!file ? (
              <div
                onDragOver={handleDragOver}
                onDragLeave={handleDragLeave}
                onDrop={handleDrop}
                onClick={() => fileInputRef.current?.click()}
                className={`
                  flex flex-col items-center justify-center py-12 px-4 rounded-lg cursor-pointer
                  transition-all duration-200
                  ${isDragging 
                    ? "bg-blue-50 dark:bg-blue-950/30 border-blue-300" 
                    : "bg-slate-50 dark:bg-slate-900/50 hover:bg-slate-100 dark:hover:bg-slate-800/50"
                  }
                  border-2 border-dashed rounded-xl
                  ${isDragging ? "border-blue-400" : "border-slate-300 dark:border-slate-700"}
                `}
              >
                <div className={`p-4 rounded-full mb-4 transition-colors ${isDragging ? "bg-blue-100 dark:bg-blue-900" : "bg-slate-200 dark:bg-slate-800"}`}>
                  <FileUp className={`h-8 w-8 ${isDragging ? "text-blue-600" : "text-slate-500"}`} />
                </div>
                <p className="text-lg font-medium text-slate-900 dark:text-white mb-1">
                  Drop your PDF here, or click to browse
                </p>
                <p className="text-sm text-slate-500 dark:text-slate-400">
                  Supports PDF files up to 500MB
                </p>
                <input
                  ref={fileInputRef}
                  type="file"
                  accept="application/pdf"
                  onChange={handleFileSelect}
                  className="hidden"
                />
              </div>
            ) : (
              <div className="space-y-6">
                {/* File Info */}
                <div className="flex items-center justify-between p-4 bg-slate-50 dark:bg-slate-900 rounded-lg">
                  <div className="flex items-center gap-3">
                    <div className="p-2 bg-red-100 dark:bg-red-900/30 rounded-lg">
                      <FileText className="h-6 w-6 text-red-600 dark:text-red-400" />
                    </div>
                    <div>
                      <p className="font-medium text-slate-900 dark:text-white truncate max-w-[300px] sm:max-w-[400px]">
                        {file.name}
                      </p>
                      <p className="text-sm text-slate-500">{formatFileSize(file.size)}</p>
                    </div>
                  </div>
                  <button
                    onClick={handleRemoveFile}
                    disabled={isProcessing}
                    className="p-2 hover:bg-slate-200 dark:hover:bg-slate-800 rounded-full transition-colors disabled:opacity-50"
                  >
                    <X className="h-5 w-5 text-slate-500" />
                  </button>
                </div>

                {/* Progress */}
                {isProcessing && (
                  <div className="space-y-2">
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-slate-600 dark:text-slate-400 flex items-center gap-2">
                        <Loader2 className="h-4 w-4 animate-spin" />
                        Removing watermarks...
                      </span>
                      <span className="font-medium text-slate-900 dark:text-white">{progress}%</span>
                    </div>
                    <Progress value={progress} className="h-2" />
                  </div>
                )}

                {/* Error */}
                {error && (
                  <div className="p-4 bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-lg text-red-700 dark:text-red-400 text-sm">
                    {error}
                  </div>
                )}

                {/* Success / Download */}
                {downloadUrl && (
                  <div className="p-4 bg-emerald-50 dark:bg-emerald-900/20 border border-emerald-200 dark:border-emerald-800 rounded-lg">
                    <div className="flex items-center gap-3">
                      <div className="p-2 bg-emerald-100 dark:bg-emerald-900/40 rounded-full">
                        <Download className="h-5 w-5 text-emerald-600 dark:text-emerald-400" />
                      </div>
                      <div className="flex-1">
                        <p className="font-medium text-emerald-900 dark:text-emerald-300">
                          Watermark removed successfully!
                        </p>
                        <p className="text-sm text-emerald-700 dark:text-emerald-400">
                          Your clean PDF is ready for download.
                        </p>
                      </div>
                      <Button onClick={handleDownload} className="bg-emerald-600 hover:bg-emerald-700 text-white">
                        <Download className="h-4 w-4 mr-2" />
                        Download
                      </Button>
                    </div>
                  </div>
                )}

                {/* Action Buttons */}
                {!isProcessing && !downloadUrl && (
                  <Button
                    onClick={handleUpload}
                    className="w-full h-12 text-lg bg-blue-600 hover:bg-blue-700 text-white"
                  >
                    <Droplets className="h-5 w-5 mr-2" />
                    Remove Watermark
                  </Button>
                )}

                {downloadUrl && (
                  <Button
                    onClick={handleRemoveFile}
                    variant="outline"
                    className="w-full"
                  >
                    Process Another PDF
                  </Button>
                )}
              </div>
            )}
          </CardContent>
        </Card>

        {/* How It Works */}
        <div className="mt-16">
          <h3 className="text-2xl font-bold text-slate-900 dark:text-white text-center mb-8">
            How It Works
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="w-12 h-12 bg-blue-100 dark:bg-blue-900/30 rounded-full flex items-center justify-center mx-auto mb-4 text-blue-600 dark:text-blue-400 font-bold text-lg">
                1
              </div>
              <h4 className="font-semibold text-slate-900 dark:text-white mb-2">Upload Your PDF</h4>
              <p className="text-sm text-slate-600 dark:text-slate-400">
                Drag and drop or select your NotebookLLM slides or any watermarked PDF.
              </p>
            </div>
            <div className="text-center">
              <div className="w-12 h-12 bg-blue-100 dark:bg-blue-900/30 rounded-full flex items-center justify-center mx-auto mb-4 text-blue-600 dark:text-blue-400 font-bold text-lg">
                2
              </div>
              <h4 className="font-semibold text-slate-900 dark:text-white mb-2">AI Detection</h4>
              <p className="text-sm text-slate-600 dark:text-slate-400">
                Our algorithm scans each page and detects watermark patterns including the NotebookLM logo.
              </p>
            </div>
            <div className="text-center">
              <div className="w-12 h-12 bg-blue-100 dark:bg-blue-900/30 rounded-full flex items-center justify-center mx-auto mb-4 text-blue-600 dark:text-blue-400 font-bold text-lg">
                3
              </div>
              <h4 className="font-semibold text-slate-900 dark:text-white mb-2">Download Clean PDF</h4>
              <p className="text-sm text-slate-600 dark:text-slate-400">
                Get your watermark-free PDF instantly. All processing happens securely on our servers.
              </p>
            </div>
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="border-t mt-16 py-8 bg-white dark:bg-slate-950">
        <div className="max-w-5xl mx-auto px-4 text-center text-sm text-slate-500 dark:text-slate-400">
          <p>PDF Watermark Remover. Removes watermarks from NotebookLLM slides and other PDFs.</p>
          <p className="mt-1">Files are processed securely and deleted immediately after.</p>
        </div>
      </footer>
    </div>
  );
}
