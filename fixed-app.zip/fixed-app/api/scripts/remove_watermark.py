import fitz  # PyMuPDF
import cv2
import numpy as np
from PIL import Image
import io
import sys
import os
import tempfile
import pytesseract

def pdf_page_to_image(doc, page_num, dpi=200):
    """Convert a PDF page to a numpy image array."""
    page = doc.load_page(page_num)
    zoom = dpi / 72
    mat = fitz.Matrix(zoom, zoom)
    pix = page.get_pixmap(matrix=mat, alpha=False)
    img_bytes = pix.tobytes("png")
    img = Image.open(io.BytesIO(img_bytes))
    return np.array(img)

def detect_watermark_region(img, page_num=0):
    """
    Detect the watermark region in the image.
    Returns (x, y, w, h) or None if not found.
    Uses multiple strategies:
    1. OCR to find 'NotebookLM' or 'Notebook LM' text
    2. Look for the NotebookLM logo pattern in bottom area
    """
    height, width = img.shape[:2]
    
    # Strategy 1: OCR-based detection
    # Focus on bottom 25% of the page where watermark typically appears
    bottom_region = img[int(height * 0.75):, :]
    
    # Convert to grayscale for OCR
    gray = cv2.cvtColor(bottom_region, cv2.COLOR_RGB2GRAY)
    
    # Try OCR
    try:
        data = pytesseract.image_to_data(gray, output_type=pytesseract.Output.DICT)
        n_boxes = len(data['text'])
        
        for i in range(n_boxes):
            text = data['text'][i].strip().lower()
            conf = int(data['conf'][i])
            
            # Look for NotebookLM-related text with reasonable confidence
            if conf > 30 and ('notebook' in text or 'note' in text or 'booklm' in text):
                x = data['left'][i]
                y = data['top'][i] + int(height * 0.75)  # Add offset
                w = data['width'][i]
                h = data['height'][i]
                
                # Expand the box to include logo (typically to the left of text)
                # Logo is roughly same height as text, positioned before text
                expanded_x = max(0, x - w * 2)  # Expand left to catch logo
                expanded_y = max(0, y - h * 0.5)
                expanded_w = min(width - expanded_x, w * 3.5)
                expanded_h = min(height - expanded_y, h * 2.5)
                
                return (int(expanded_x), int(expanded_y), int(expanded_w), int(expanded_h))
    except Exception as e:
        print(f"OCR detection failed on page {page_num}: {e}", file=sys.stderr)
    
    # Strategy 2: Bottom-right corner analysis
    # The watermark is typically in the bottom-right corner
    # Look for dark text/logo on light background
    bottom_right = img[int(height * 0.85):, int(width * 0.7):]
    
    # Convert to grayscale and threshold
    gray_br = cv2.cvtColor(bottom_right, cv2.COLOR_RGB2GRAY)
    
    # Adaptive threshold to find dark text
    thresh = cv2.adaptiveThreshold(gray_br, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, 
                                   cv2.THRESH_BINARY_INV, 11, 2)
    
    # Find contours
    contours, _ = cv2.findContours(thresh, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    
    # Filter contours that could be the watermark
    best_contour = None
    best_score = 0
    
    for cnt in contours:
        x, y, w, h = cv2.boundingRect(cnt)
        area = w * h
        aspect = w / h if h > 0 else 0
        
        # Watermark is typically a small horizontal element in bottom-right
        # Area between 1000 and 50000 pixels at 200 DPI
        if 500 < area < 50000 and 1.5 < aspect < 8:
            # Check if it's in the right area of bottom-right region
            score = area * aspect
            if score > best_score:
                best_score = score
                best_contour = (x + int(width * 0.7), y + int(height * 0.85), w, h)
    
    if best_contour:
        # Expand slightly
        x, y, w, h = best_contour
        expanded_x = max(0, x - 20)
        expanded_y = max(0, y - 10)
        expanded_w = min(width - expanded_x, w + 40)
        expanded_h = min(height - expanded_y, h + 20)
        return (int(expanded_x), int(expanded_y), int(expanded_w), int(expanded_h))
    
    return None

def remove_watermark_from_page(img, watermark_region):
    """Remove watermark from image using inpainting."""
    if watermark_region is None:
        return img
    
    x, y, w, h = watermark_region
    height, width = img.shape[:2]
    
    # Ensure bounds
    x = max(0, x)
    y = max(0, y)
    w = min(w, width - x)
    h = min(h, height - y)
    
    # Create mask for inpainting
    mask = np.zeros((height, width), dtype=np.uint8)
    
    # Dilate the region slightly to ensure full coverage
    kernel = np.ones((15, 15), np.uint8)
    mask[y:y+h, x:x+w] = 255
    mask = cv2.dilate(mask, kernel, iterations=2)
    
    # Use inpainting to fill the watermark region
    # TELEA is usually better for structured content like slides
    result = cv2.inpaint(img, mask, 3, cv2.INPAINT_TELEA)
    
    return result

def process_pdf(input_path, output_path, dpi=200):
    """Process entire PDF to remove watermarks."""
    doc = fitz.open(input_path)
    num_pages = len(doc)
    
    if num_pages == 0:
        raise ValueError("PDF has no pages")
    
    # First pass: detect watermark regions on all pages
    watermark_regions = []
    
    for page_num in range(num_pages):
        img = pdf_page_to_image(doc, page_num, dpi)
        region = detect_watermark_region(img, page_num)
        watermark_regions.append(region)
        print(f"Page {page_num + 1}/{num_pages}: {'watermark found' if region else 'no watermark detected'}", file=sys.stderr)
    
    # Check if we found watermarks on majority of pages
    detected_count = sum(1 for r in watermark_regions if r is not None)
    
    if detected_count == 0:
        print("No watermarks detected. Copying PDF as-is.", file=sys.stderr)
        doc.save(output_path)
        doc.close()
        return
    
    # If detected on some but not all, use the most common region for undetected pages
    # Find the average region from detected ones
    detected_regions = [r for r in watermark_regions if r is not None]
    
    if detected_regions and detected_count < num_pages:
        # Use median position
        xs = [r[0] for r in detected_regions]
        ys = [r[1] for r in detected_regions]
        ws = [r[2] for r in detected_regions]
        hs = [r[3] for r in detected_regions]
        
        avg_region = (
            int(np.median(xs)),
            int(np.median(ys)),
            int(np.median(ws)),
            int(np.median(hs))
        )
        
        # Fill in missing regions
        for i in range(num_pages):
            if watermark_regions[i] is None:
                watermark_regions[i] = avg_region
    
    # Second pass: remove watermarks and create new PDF
    output_doc = fitz.open()
    
    for page_num in range(num_pages):
        img = pdf_page_to_image(doc, page_num, dpi)
        cleaned_img = remove_watermark_from_page(img, watermark_regions[page_num])
        
        # Convert back to PIL and save as PNG bytes
        pil_img = Image.fromarray(cleaned_img)
        img_bytes = io.BytesIO()
        pil_img.save(img_bytes, format='PNG', optimize=False)
        img_bytes.seek(0)
        
        # Create new page with same dimensions
        page_rect = doc[page_num].rect
        new_page = output_doc.new_page(width=page_rect.width, height=page_rect.height)
        
        # Insert image into page
        new_page.insert_image(page_rect, stream=img_bytes.read())
        
        print(f"Processed page {page_num + 1}/{num_pages}", file=sys.stderr)
    
    # Save output
    output_doc.save(output_path, garbage=4, deflate=True)
    output_doc.close()
    doc.close()
    
    print(f"Saved cleaned PDF to {output_path}", file=sys.stderr)

if __name__ == "__main__":
    if len(sys.argv) < 3:
        print("Usage: python remove_watermark.py <input.pdf> <output.pdf> [dpi]", file=sys.stderr)
        sys.exit(1)
    
    input_pdf = sys.argv[1]
    output_pdf = sys.argv[2]
    dpi = int(sys.argv[3]) if len(sys.argv) > 3 else 200
    
    if not os.path.exists(input_pdf):
        print(f"Error: Input file not found: {input_pdf}", file=sys.stderr)
        sys.exit(1)
    
    try:
        process_pdf(input_pdf, output_pdf, dpi)
        print("SUCCESS", flush=True)
    except Exception as e:
        print(f"Error processing PDF: {e}", file=sys.stderr)
        sys.exit(1)
