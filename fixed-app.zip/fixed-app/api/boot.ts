import { Hono } from "hono";
import { bodyLimit } from "hono/body-limit";
import type { HttpBindings } from "@hono/node-server";
import { fetchRequestHandler } from "@trpc/server/adapters/fetch";
import { appRouter } from "./router";
import { createContext } from "./context";
import { env } from "./lib/env";
import { execFile } from "child_process";
import { promisify } from "util";
import * as fs from "fs/promises";
import * as path from "path";
import * as os from "os";
import { fileURLToPath } from "url";

const execFileAsync = promisify(execFile);

// Resolve __dirname in ESM
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = new Hono<{ Bindings: HttpBindings }>();

// 500MB limit for large PDFs — return a proper JSON 413 so the UI can display it
app.use(
  bodyLimit({
    maxSize: 500 * 1024 * 1024,
    onError: (c) =>
      c.json({ error: "File too large. Maximum upload size is 500 MB." }, 413),
  })
);

// PDF watermark removal endpoint
app.post("/api/pdf/remove-watermark", async (c) => {
  const tempDir = await fs.mkdtemp(path.join(os.tmpdir(), "pdf-watermark-"));
  
  try {
    const formData = await c.req.formData();
    const file = formData.get("pdf") as File | null;
    
    if (!file || file.type !== "application/pdf") {
      return c.json({ error: "Please upload a valid PDF file" }, 400);
    }
    
    const inputPath = path.join(tempDir, "input.pdf");
    const outputPath = path.join(tempDir, "output.pdf");
    
    // Write uploaded file to disk
    const arrayBuffer = await file.arrayBuffer();
    await fs.writeFile(inputPath, Buffer.from(arrayBuffer));
    
    // Run Python watermark removal script
    // Use __dirname so the path is correct regardless of where the process is started from
    const scriptPath = path.join(__dirname, "scripts", "remove_watermark.py");
    
    await execFileAsync("python3", [scriptPath, inputPath, outputPath, "200"], {
      timeout: 300000, // 5 minutes timeout
      maxBuffer: 10 * 1024 * 1024, // 10MB stdout/stderr buffer
    });
    
    // Read the output file
    const outputBuffer = await fs.readFile(outputPath);
    
    // Return the cleaned PDF
    return new Response(outputBuffer, {
      headers: {
        "Content-Type": "application/pdf",
        "Content-Disposition": `attachment; filename="${file.name.replace('.pdf', '')}_cleaned.pdf"`,
      },
    });
    
  } catch (error) {
    console.error("PDF processing error:", error);
    const message = error instanceof Error ? error.message : "Unknown error";
    return c.json({ error: "Failed to process PDF: " + message }, 500);
  } finally {
    // Clean up temp files
    try {
      await fs.rm(tempDir, { recursive: true, force: true });
    } catch (e) {
      console.error("Failed to clean up temp dir:", e);
    }
  }
});

// tRPC handler
app.use("/api/trpc/*", async (c) => {
  return fetchRequestHandler({
    endpoint: "/api/trpc",
    req: c.req.raw,
    router: appRouter,
    createContext,
  });
});

app.all("/api/*", (c) => c.json({ error: "Not Found" }, 404));

export default app;

if (env.isProduction) {
  const { serve } = await import("@hono/node-server");
  const { serveStaticFiles } = await import("./lib/vite");
  serveStaticFiles(app);

  const port = parseInt(process.env.PORT || "3000");
  serve({ fetch: app.fetch, port }, () => {
    console.log(`Server running on http://localhost:${port}/`);
  });
}
